//Variaveis da bolinha
let xBolinha = 300;
let yBolinha = 200;
let diametro = 30;
let raio = diametro / 2;

//Variaveis da velocidade
let velocidadeXBolinha = 6;
let velocidadeYBolinha = 6;

function setup() {
  createCanvas(800, 600);
  trilha.loop();
}

//variaveis da raquete
let xRaquete = 5
let yRaquete = 150
let RaqueteComprimento = 10
let RaqueteAltura = 90
let colidiu = false;

//variaveis do oponente
let xRaqueteOponente = 785;
let yRaqueteOponente = 150;
let velocidadeyOponente;

//placar do jogo
let meusPontos = 0;
let pontosOponente = 0;

//sons do jogo
let raquetada;
let ponto;
let trilha;

function preload(){
  trilha = loadSound ("trilha.mp3");
  raquetada = loadSound ("raquetada.mp3");
  ponto = loadSound ("ponto.mp3")
}

function draw() {
  background(0);
  mostraBolinha();
  movimentaBolinha();
  BordaBolinha ();
  mostraRaquete(xRaquete, yRaquete);
  movimentaMinhaRaquete();
  verificaColisaoRaquete(xRaquete, yRaquete);
  mostraRaquete(xRaqueteOponente, yRaqueteOponente);
  //movimentaRaqueteOponente();
  VerificaColisaoRaquete(xRaqueteOponente, yRaqueteOponente);
  incluiPlacar();
  marcaPonto();
}

function mostraBolinha(){
  circle(xBolinha, yBolinha, diametro);
}

function movimentaBolinha (){
  xBolinha += velocidadeXBolinha;
  yBolinha += velocidadeYBolinha;
}

function BordaBolinha(){
   if(xBolinha + raio > width ||
    xBolinha - raio < 0){
    velocidadeXBolinha *= -1;
  }
  
  if (yBolinha + raio > height ||
     yBolinha - raio < 0){
    velocidadeYBolinha *= -1;
  }
}

function mostraRaquete (x,y){
  rect(x, y, RaqueteComprimento, RaqueteAltura);
  
}

function movimentaMinhaRaquete (){
  if (keyIsDown(UP_ARROW)){
    yRaquete -= 10;
  }
  
  if (keyIsDown(DOWN_ARROW)){
    yRaquete += 10;
  }
  
}

function verificaColisaoRaquete (){
  if (xBolinha - raio < xRaquete + RaqueteComprimento
     && yBolinha - raio < yRaquete + RaqueteAltura && yBolinha + raio > yRaquete){
    velocidadeXBolinha *= -1;
    raquetada.play();
  }
}

function VerificaColisaoRaquete(x,y){
  colidiu = 
  collideRectCircle(x, y, RaqueteComprimento, RaqueteAltura, xBolinha, yBolinha,raio);
  if (colidiu){
   velocidadeXBolinha *= - 1; 
    raquetada.play();
  }
}

function movimentaRaqueteOponente(){
  velocidadeyOponente = yBolinha -yRaqueteOponente - RaqueteComprimento /2 - 30;
  yRaqueteOponente += velocidadeyOponente
}

function incluiPlacar(){
  stroke(255);
  textAlign(CENTER);
  textSize (20);
  fill (color(255,140,0));
  rect (160,10,40,20);
  fill (color(255,140,0));
  rect (560,10,40,20);
  fill (255);
  
  text (pontosOponente, 578, 26);
  text (meusPontos, 178, 26);
}

function marcaPonto() {
    if (xBolinha > 780) {
        meusPontos += 1;
      ponto.play();
    }
    if (xBolinha < 15) {
        pontosOponente += 1;
      ponto.play();
    }
}


function bolinhaNaoFicaPresa(){
    if (XBolinha - raio < 0){
    XBolinha = 30
      if (YBolinha - raio > 780){
        YBolinha = 30
      }
    }
}


